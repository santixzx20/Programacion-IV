import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap';

// 1. Obtenemos la referencia al elemento <main>
const main = document.getElementById('contenido-principal');

// 2. Obtenemos las referencias a los botones/enlaces
const linkInicio = document.getElementById('link-inicio');
const linkIncidencias = document.getElementById('link-incidencias');
const linkContacto = document.getElementById('link-contacto');

// 3. Escuchamos el clic en "Inicio"
linkInicio.addEventListener('click', (evento) => {
  evento.preventDefault(); // Evita que la página recargue o salte hacia arriba
  main.innerHTML = `
    <h2>Panel de Inicio</h2>
    <p>Bienvenido al sistema de registro de incidencias del municipio.</p>
  `;
});

// 4. Escuchamos el clic en "Incidencias"
linkIncidencias.addEventListener('click', (evento) => {
  evento.preventDefault();
  main.innerHTML = `
    <h2>Gestión de Incidencias</h2>
    <p>Aquí se listarán las incidencias reportadas.</p>
    <a class="btn btn-primary facebook-boton" href="https://www.facebook.com/" target="_blank">Facebook</a>
  `;
});

// 5. Escuchamos el clic en "Contacto"
linkContacto.addEventListener('click', (evento) => {
  evento.preventDefault();
  main.innerHTML = `
    <h2>Mesa de Ayuda / Contacto</h2>
    <p>Comunícate con el área de soporte técnico.</p>
    <a class="btn btn-success whatsapp-boton" href="https://web.whatsapp.com/" target="_blank">Whatsapp</a>
    <a class="btn btn-primary facebook-boton" href="https://www.facebook.com/" target="_blank">Facebook</a>
  `;
});